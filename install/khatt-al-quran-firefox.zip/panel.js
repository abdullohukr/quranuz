/* The panel is the website in a frame. Its "Insert" button sends {html, text}; here it is put into the field
   that has the focus in the current tab. Where that is not possible (no field, Google Docs, a page the
   extension may not touch) the answer is ok: false and the website tells to paste: it already copied. */
var api = typeof browser !== 'undefined' ? browser : chrome;
var SITE = 'https://quran.abdulloh.org', frame = document.getElementById('app');

/* runs inside the page, in every frame (descend: false) or in the top page only (descend: true). The frame whose
   focused element is a field inserts; a frame whose focused element is a frame leaves it to that frame. */
function insertHere(html, text, descend) {
  if (/(^|\.)docs\.google\.com$/.test(location.hostname)) return false;   // Docs draws on a canvas: paste works, typing in does not
  var el = document.activeElement;
  while (el && el.tagName === 'IFRAME') {
    if (!descend) return false;
    try { el = el.contentDocument.activeElement; } catch (e) { return false; }   // editors in same-origin frames (TinyMCE, …)
  }
  if (!el) return false;
  var doc = el.ownerDocument;
  if (el.isContentEditable) {
    el.focus();
    // the first inserted block is merged into the current line (the Arabic lost its right-to-left paragraph);
    // a line break in front takes that place
    if (doc.execCommand('insertHTML', false, '<br>' + html)) return true;
    return doc.execCommand('insertText', false, text);
  }
  if (el.tagName === 'TEXTAREA' || (el.tagName === 'INPUT' && /^(text|search|url|email)?$/i.test(el.type || ''))) {
    if (el.readOnly || el.disabled) return false;
    el.focus();
    if (doc.execCommand('insertText', false, text)) return true;           // keeps undo, fires input events
    el.setRangeText(text, el.selectionStart || 0, el.selectionEnd || 0, 'end');
    el.dispatchEvent(new Event('input', { bubbles: true }));
    return true;
  }
  return false;
}

function reply(ok, error) {
  frame.contentWindow.postMessage({ type: 'khatt-result', ok: ok, error: error || '' }, SITE);
}

window.addEventListener('message', function (e) {
  var d = e.data;
  if (e.origin !== SITE || e.source !== frame.contentWindow || !d || d.type !== 'khatt-insert') return;
  api.tabs.query({ active: true, currentWindow: true }).then(function (tabs) {
    var tab = tabs[0];
    if (!tab) return reply(false);
    var run = function (allFrames) {
      return api.scripting.executeScript({ target: { tabId: tab.id, allFrames: allFrames }, func: insertHere, args: [d.html, d.text, !allFrames] });
    };
    // all frames first (editors inside frames); where some frame is not allowed, the top page alone
    return run(true).catch(function () { return run(false); }).then(function (res) {
      reply((res || []).some(function (r) { return r && r.result === true; }));
    });
  }).catch(function () { reply(false); });
});
