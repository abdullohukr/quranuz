/* Khatt al-Quran extension: the toolbar button and the context menu open the panel (Chrome / Edge: side panel,
   Firefox: sidebar). Opening it from either grants access to the current tab, so the panel can insert there. */
var api = typeof browser !== 'undefined' ? browser : chrome;

if (api.sidePanel && api.sidePanel.setPanelBehavior) api.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
else if (api.action && api.sidebarAction) api.action.onClicked.addListener(function () { api.sidebarAction.toggle(); });

api.runtime.onInstalled.addListener(function () {
  api.contextMenus.create({ id: 'khatt-insert', title: api.i18n.getMessage('menuInsert'), contexts: ['editable'] });
});
api.contextMenus.onClicked.addListener(function (info, tab) {
  if (info.menuItemId !== 'khatt-insert') return;
  if (api.sidePanel && api.sidePanel.open) api.sidePanel.open({ windowId: tab.windowId });   // must stay synchronous (user gesture)
  else if (api.sidebarAction) api.sidebarAction.open();
});
