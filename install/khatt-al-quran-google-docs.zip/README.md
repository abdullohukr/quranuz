# Khatt al-Quran for Google Docs

An editor add-on: **Extensions → Khatt al-Quran** opens the panel in a sidebar; **Insert** puts the ayah, translation
and tafsir after the paragraph with the cursor, with fonts, sizes, bold/italic/colour and right-to-left paragraphs
as set in the panel's settings. The Arabic text uses *Scheherazade New* (a Google font, available in Docs). The
page-font mushafs (QPC V1/V2/V4) are not offered here.

Files: `Code.gs` (menu, sidebar, `insertAyah`), `Sidebar.html` (the website https://quran.abdulloh.org/ in a frame,
`?host=gdocs`), `appsscript.json` (scopes: only the open document and the sidebar).

## Try it in one document (2 minutes)

1. Open a Google Doc → **Extensions → Apps Script**.
2. Replace the contents of `Code.gs` with this `Code.gs`; **+ → HTML** named `Sidebar`, paste `Sidebar.html`.
3. **Project Settings → Show "appsscript.json"**, paste `appsscript.json`. Save.
4. Reload the document: **Extensions → Khatt al-Quran → Khatt al-Quran**. Allow access the first time.

## For all your documents (test deployment)

In the Apps Script project (created at https://script.google.com/ with the three files): **Deploy → Test
deployments → Install** (type: Editor Add-on). The add-on then appears under **Extensions** in every document.

## Publishing (Google Workspace Marketplace)

Needs a Google Cloud project linked to the script, the OAuth consent screen (scopes above; both are non-sensitive),
the Marketplace SDK listing (name, icons from `web/assets/`, privacy `https://quran.abdulloh.org/privacy.html`,
terms `https://quran.abdulloh.org/terms.html`) and Google's review.

---

**По-русски:** откройте документ → «Расширения → Apps Script», вставьте три файла (`Code.gs`, `Sidebar` как HTML,
`appsscript.json` через «Настройки проекта»), сохраните и обновите документ: появится «Расширения → Khatt al-Quran».
Для всех документов — «Начать развертывание → Тестовые развертывания → Установить». Публикация в Marketplace —
через проект Google Cloud и проверку Google.
