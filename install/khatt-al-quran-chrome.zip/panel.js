/* The panel is the website in a frame. Messages with the website (only from / to its own origin):
     site -> panel  khatt-insert {html, text, mode, picHtml, restHtml, pic}: put it into the field that has the focus
                    in the current tab (see khattInsertHere in insert.js); the answer is khatt-result {ok, ask, pic}.
                    Where that is not possible (no field, Google Docs, a page the extension may not touch) ok is false
                    and the website tells to paste: it already copied.
                    khatt-ready: the website is ready for messages; khatt-pref {extInsert, fav, hist}: its choice, favourites
                    or history changed.
     panel -> site  khatt-search {q}: search this (context menu, shortcut); khatt-pref {extInsert, fav, hist}: the saved ones.
   The choice of the way to insert into editors (extInsert), the favourites ("2:255-255,…") and the history ([[sura, from,
   to, seconds(, word from, word to)], …]) are also kept in storage.sync, so they are not lost with the site's data. */
var api = typeof browser !== 'undefined' ? browser : chrome;
var SITE = 'https://quran.abdulloh.org', frame = document.getElementById('app');
var area = api.storage.session || api.storage.local, ready = false;

function post(msg) { if (frame.contentWindow) frame.contentWindow.postMessage(msg, SITE); }
function reply(r, error) {
  post({ type: 'khatt-result', ok: r === true || r === 'nopic', ask: r === 'ask', pic: r === 'nopic' ? 'none' : '', error: error || '' });
}

/* a search asked for by the context menu or the shortcut (the newest one, if it is not old) */
function takeSearch() {
  if (!ready) return;
  area.get('khattSearch').then(function (s) {
    var x = s && s.khattSearch;
    if (!x || !x.q) return;
    area.remove('khattSearch');
    if (Date.now() - (x.t || 0) < 120000) post({ type: 'khatt-search', q: x.q });
  }).catch(function () {});
}
api.storage.onChanged.addListener(function (ch) { if (ch.khattSearch && ch.khattSearch.newValue) takeSearch(); });

var liveTimer = null, liveLast = '', liveBusy = false;
function liveTick() {
  if (document.hidden || liveBusy) return;
  liveBusy = true;
  api.tabs.query({ active: true, currentWindow: true }).then(function (tabs) {
    var tab = tabs[0]; if (!tab) return;
    return khattRun(api, tab.id, khattSelectedText).then(function (txt) {
      if (txt && /[\u0600-\u06FF]/.test(txt) && txt !== liveLast) { liveLast = txt; post({ type: 'khatt-search', q: String(txt).slice(0, 400), live: true }); }
    });
  }).catch(function () {}).then(function () { liveBusy = false; });
}

window.addEventListener('message', function (e) {
  var d = e.data;
  if (e.origin !== SITE || e.source !== frame.contentWindow || !d) return;
  if (d.type === 'khatt-ready') {
    ready = true;
    api.storage.sync.get(['extInsert', 'khattFav', 'khattHist']).then(function (s) {
      var msg = { type: 'khatt-pref', extInsert: (s && s.extInsert) || '' };
      if (s && typeof s.khattFav === 'string') msg.fav = s.khattFav;           // only what is saved: the site gives the rest
      if (s && Array.isArray(s.khattHist)) msg.hist = s.khattHist;
      post(msg);
    }, function () {});
    takeSearch();
    return;
  }
  if (d.type === 'khatt-pref') {
    if (/^(ask|text|picture)$/.test(d.extInsert || '')) api.storage.sync.set({ extInsert: d.extInsert }).catch(function () {});
    if (typeof d.fav === 'string' && d.fav.length < 8000) api.storage.sync.set({ khattFav: d.fav }).catch(function () {});
    if (Array.isArray(d.hist) && d.hist.length <= 50) api.storage.sync.set({ khattHist: d.hist }).catch(function () {});
    return;
  }
  if (d.type === 'khatt-live') {                       // live search: the selected Arabic text of the page, every 1.5 s while it is on
    clearInterval(liveTimer); liveLast = '';
    if (d.on) liveTimer = setInterval(liveTick, 1500);
    return;
  }
  if (d.type !== 'khatt-insert') return;
  var job = { html: String(d.html || ''), text: String(d.text || ''), mode: /^(ask|text|picture)$/.test(d.mode || '') ? d.mode : 'text',
              picHtml: d.picHtml ? String(d.picHtml) : '', restHtml: d.restHtml ? String(d.restHtml) : '', pic: d.pic ? String(d.pic) : '' };
  api.tabs.query({ active: true, currentWindow: true }).then(function (tabs) {
    var tab = tabs[0];
    if (!tab) return reply(false);
    return khattRun(api, tab.id, khattInsertHere, function (all) { return [job, !all]; }).then(function (r) {
      // "Insert the last ayah again" (context menu): in an editor the way chosen now, never a question
      if (r === true || r === 'nopic') api.storage.local.set({ khattLast: Object.assign({}, job, { mode: job.mode === 'ask' ? 'text' : job.mode }) }).catch(function () {});
      reply(r);
    });
  }).catch(function () { reply(false); });
});
