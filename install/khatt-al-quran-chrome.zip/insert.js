/* Functions that run INSIDE the web page (scripting.executeScript serializes them: no outside variables).
   Used by panel.js (the Insert button) and background.js (search the selection, insert the last ayah again). */

/* d = {html, text, mode: 'ask' | 'text' | 'picture', picHtml, restHtml, pic}; runs in every frame (descend: false)
   or in the top page only (descend: true). The frame whose focused element is a field inserts.
   Answers: true (inserted), 'ask' (an editor and the way is not chosen yet: nothing inserted),
   'nopic' (the editor does not keep pictures: inserted as text), false (no field here). */
function khattInsertHere(d, descend) {
  if (/(^|\.)docs\.google\.com$/.test(location.hostname)) return false;   // Docs draws on a canvas: paste works, typing in does not
  var el = document.activeElement;
  while (el && el.tagName === 'IFRAME') {
    if (!descend) return false;
    try { el = el.contentDocument.activeElement; } catch (e) { return false; }   // editors in same-origin frames (TinyMCE, …)
  }
  if (!el) return false;
  var doc = el.ownerDocument;
  // plain text fields: only text is possible there (no font, no picture)
  if (el.tagName === 'TEXTAREA' || (el.tagName === 'INPUT' && /^(text|search|url|email)?$/i.test(el.type || ''))) {
    if (el.readOnly || el.disabled) return false;
    el.focus();
    if (doc.execCommand('insertText', false, d.text)) return true;           // keeps undo, fires input events
    el.setRangeText(d.text, el.selectionStart || 0, el.selectionEnd || 0, 'end');
    el.dispatchEvent(new Event('input', { bubbles: true }));
    return true;
  }
  if (!el.isContentEditable) return false;
  if (d.mode === 'ask') return 'ask';
  el.focus();
  /* QPC page fonts (one font per mushaf page, named QCF4001_COLOR / QCF2001 / QCF_P001): their @font-face rules
     are added to the page, so the text shows in its font where the page allows fonts from the CDN */
  /* the sources in one src, in order (the browser takes the next one when a source does not answer): our own copies
     (site, jsDelivr, GitHub, Hugging Face, archive.org), the QUL CDN last (as fontSources in the WordPress plugin,
     qpcSources in app.js) */
  function sources(v, n) {
    var f = 'qpc/' + v + '/p' + n + '.woff2';
    return ['https://quran.abdulloh.org/fonts/' + f, 'https://cdn.jsdelivr.net/gh/abdullohukr/quranuz@main/fonts/' + f,
      'https://raw.githubusercontent.com/abdullohukr/quranuz/main/fonts/' + f,
      'https://huggingface.co/datasets/abdullohukr/khatt-al-quran-fonts/resolve/main/' + f,
      'https://archive.org/download/khatt-al-quran-fonts/' + f,
      'https://static-cdn.tarteel.ai/qul/fonts/quran_fonts/' + (v === 'v4' ? 'v4-tajweed' : v) + '/woff2/p' + n + '.woff2'];
  }
  function fonts() {
    var found = String(d.html || '').match(/QCF(?:4\d{3}_COLOR|2\d{3}|_P\d{3})/g);
    if (!found || !doc.head) return;
    var done = doc.__khattFonts || (doc.__khattFonts = {}), css = '';
    found.forEach(function (fam) {
      var m, u = null;
      if ((m = /^QCF4(\d{3})_COLOR$/.exec(fam))) u = sources('v4', +m[1]);
      else if ((m = /^QCF2(\d{3})$/.exec(fam))) u = sources('v2', +m[1]);
      else if ((m = /^QCF_P(\d{3})$/.exec(fam))) u = sources('v1', +m[1]);
      if (!u || done[fam]) return;
      done[fam] = 1;
      css += "@font-face{font-family:'" + fam + "';src:" + u.map(function (x) { return "url('" + x + "') format('woff2')"; }).join(',') + ';font-display:swap}';
    });
    if (css) { var st = doc.createElement('style'); st.setAttribute('data-khatt', 'fonts'); st.textContent = css; doc.head.appendChild(st); }
  }
  // the first inserted block is merged into the current line (the Arabic lost its right-to-left paragraph);
  // a line break in front takes that place
  function asText() {
    fonts();
    if (doc.execCommand('insertHTML', false, '<br>' + d.html)) return true;
    return doc.execCommand('insertText', false, d.text);
  }
  if (d.mode !== 'picture' || !d.picHtml) return asText();
  var mark = String(d.pic || '').slice(0, 160);
  // the picture in this editor (the same picture may be elsewhere on the page)
  var kept = function () { return [].some.call(el.querySelectorAll('img'), function (im) { return im.isConnected && (im.getAttribute('src') || '').slice(0, 160) === mark; }); };
  if (!doc.execCommand('insertHTML', false, '<br>' + d.picHtml)) return asText() ? 'nopic' : false;
  // editors (ProseMirror, Lexical, …) may take the picture out again after a moment: look once more
  return new Promise(function (done) {
    setTimeout(function () {
      el.focus();
      if (!kept()) { done(asText() ? 'nopic' : false); return; }
      if (d.restHtml) doc.execCommand('insertHTML', false, d.restHtml);   // translation, tafsir after the picture
      done(true);
    }, 200);
  });
}

/* the selected text of the page: in a text field or in the page (frames: every frame answers, the first one counts) */
function khattSelectedText() {
  var el = document.activeElement, s = '';
  try {
    if (el && (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') && typeof el.selectionStart === 'number') s = el.value.slice(el.selectionStart, el.selectionEnd);
  } catch (e) {}
  return (s || String(window.getSelection ? window.getSelection() : '')).trim();
}

/* executeScript in every frame, the top page alone where some frame is not allowed; the first useful answer */
function khattRun(api, tabId, func, args) {
  var run = function (allFrames) {
    return api.scripting.executeScript({ target: { tabId: tabId, allFrames: allFrames }, func: func, args: args ? args(allFrames) : [] });
  };
  return run(true).catch(function () { return run(false); }).then(function (res) {
    var hit = (res || []).filter(function (r) { return r && r.result; })[0];
    return hit ? hit.result : false;
  });
}
