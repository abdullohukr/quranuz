/* Khatt al-Quran extension: the toolbar button, the context menu and the keyboard shortcuts open the panel
   (Chrome / Edge: side panel, Firefox: sidebar). Opening it from any of them grants access to the current tab,
   so the panel can insert there.
     "Insert a Quran ayah here" (in a field)       opens the panel
     "Search in Khatt al-Quran" (on a selection)   opens the panel and searches the selected text
     "Insert the last ayah again" (in a field)     inserts what the panel inserted last, without opening it
   The search goes to the panel through storage.session (read when the panel is ready, or at once when it is open). */
var api = typeof browser !== 'undefined' ? browser : chrome;
if (typeof importScripts === 'function' && typeof khattInsertHere === 'undefined') importScripts('insert.js');   // Chrome service worker

if (api.sidePanel && api.sidePanel.setPanelBehavior) api.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
else if (api.action && api.sidebarAction) api.action.onClicked.addListener(function () { api.sidebarAction.toggle(); });

var area = function () { return api.storage.session || api.storage.local; };

function menus() {
  Promise.resolve(api.contextMenus.removeAll()).catch(function () {}).then(function () {
    api.contextMenus.create({ id: 'khatt-insert', title: api.i18n.getMessage('menuInsert'), contexts: ['editable'] });
    api.contextMenus.create({ id: 'khatt-again', title: api.i18n.getMessage('menuAgain'), contexts: ['editable'] });
    api.contextMenus.create({ id: 'khatt-search', title: api.i18n.getMessage('menuSearch'), contexts: ['selection'] });
  });
}
api.runtime.onInstalled.addListener(menus);

/* must stay synchronous in the click / shortcut handler (it counts as the user's action only there) */
function openPanel(tab) {
  try {
    if (api.sidePanel && api.sidePanel.open) {
      var p = api.sidePanel.open(tab && tab.windowId != null ? { windowId: tab.windowId } : { tabId: tab.id });
      if (p && p.catch) p.catch(function () {});
    } else if (api.sidebarAction) api.sidebarAction.open();
  } catch (e) {}
}
function search(q) {
  q = String(q || '').trim().slice(0, 500);
  if (q) area().set({ khattSearch: { q: q, t: Date.now() } });
}

api.contextMenus.onClicked.addListener(function (info, tab) {
  if (info.menuItemId === 'khatt-insert') openPanel(tab);
  else if (info.menuItemId === 'khatt-search') { openPanel(tab); search(info.selectionText); }
  else if (info.menuItemId === 'khatt-again') {
    api.storage.local.get('khattLast').then(function (s) {
      var d = s && s.khattLast;
      if (!d || !tab) return;          // nothing inserted yet (the menu item says "again")
      return khattRun(api, tab.id, khattInsertHere, function (all) { return [d, !all]; });
    }).catch(function () {});
  }
});

if (api.commands && api.commands.onCommand) api.commands.onCommand.addListener(function (cmd, tab) {
  if (cmd !== 'search-selection') return;
  if (tab) openPanel(tab);
  else if (api.sidebarAction) api.sidebarAction.open();
  (tab ? Promise.resolve([tab]) : api.tabs.query({ active: true, currentWindow: true })).then(function (tabs) {
    if (!tabs[0]) return;
    return khattRun(api, tabs[0].id, khattSelectedText).then(search);
  }).catch(function () {});
});
