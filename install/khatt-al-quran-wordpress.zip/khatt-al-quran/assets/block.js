/* Block "Quran ayah": no build step, the editor's own React (wp.element). The saved markup is the HTML from the
   website inside <div class="khatt-ayah">, so the post shows it without the plugin too (only the font is lost). */
(function (wp) {
  'use strict';
  var el = wp.element.createElement, RawHTML = wp.element.RawHTML, __ = wp.i18n.__;
  var be = wp.blockEditor, cmp = wp.components, K = window.KhattAlQuran;
  var useBlockProps = be.useBlockProps || function (p) { return p || {}; };
  var icon = el('svg', { viewBox: '0 0 24 24', width: 24, height: 24 },
    el('path', { d: 'M4 5.5C4 4.7 4.7 4 5.5 4H11v16H5.5A1.5 1.5 0 0 1 4 18.5v-13Zm9-1.5h5.5c.8 0 1.5.7 1.5 1.5v13c0 .8-.7 1.5-1.5 1.5H13V4Z', fill: 'currentColor' }));

  wp.blocks.registerBlockType('khatt/ayah', {
    apiVersion: 3,
    title: __('Quran ayah', 'khatt-al-quran'),
    description: __('Arabic text, translation and tafsir from Khatt al-Quran.', 'khatt-al-quran'),
    category: 'text',
    icon: icon,
    keywords: ['quran', 'ayah', 'aya', 'قرآن', 'آية', 'Коран', 'аят', 'оят'],
    supports: { html: false, align: ['wide', 'full'] },
    attributes: { html: { type: 'string', source: 'html', selector: '.khatt-ayah' } },

    edit: function (props) {
      var html = props.attributes.html;
      function choose() { K.pick(function (h) { props.setAttributes({ html: h }); }); }
      var bp = useBlockProps();
      if (!html) {
        return el('div', bp, el(cmp.Placeholder, {
          icon: icon, label: __('Quran ayah', 'khatt-al-quran'),
          instructions: __('Find an ayah, choose the translation and tafsir, press "Insert".', 'khatt-al-quran')
        }, el(cmp.Button, { variant: 'primary', isPrimary: true, onClick: choose }, __('Choose an ayah', 'khatt-al-quran'))));
      }
      return el('div', bp,
        el(be.BlockControls, null, el(cmp.ToolbarGroup, null,
          el(cmp.ToolbarButton, { icon: 'edit', label: __('Choose another ayah', 'khatt-al-quran'), onClick: choose }))),
        el('div', { className: 'khatt-ayah' }, el(RawHTML, null, html)));
    },

    save: function (props) {
      var bp = be.useBlockProps && be.useBlockProps.save ? be.useBlockProps.save() : {};
      return el('div', bp, el('div', { className: 'khatt-ayah' }, el(RawHTML, null, props.attributes.html)));
    }
  });
})(window.wp);
