/* Khatt al-Quran: a side panel in the block editor, like the task pane in Word.
   The panel is the website (?host=wp) in a frame; its "Insert" button posts {type: 'khatt-insert', html, text}.
   The ayah goes into the post as ordinary paragraph blocks (Arabic right-to-left, translation, ...) at the cursor,
   so it is plain editable text, not a special object. Only messages from the website itself are taken. */
(function (wp) {
  'use strict';
  var K = window.KhattAlQuran || {};
  var el = wp.element.createElement, __ = wp.i18n.__;
  var PluginSidebar = (wp.editor && wp.editor.PluginSidebar) || (wp.editPost && wp.editPost.PluginSidebar);
  var MoreItem = (wp.editor && wp.editor.PluginSidebarMoreMenuItem) || (wp.editPost && wp.editPost.PluginSidebarMoreMenuItem);
  if (!wp.plugins || !PluginSidebar) return;

  /* QPC page fonts: the family name says which file it is (QCF4001_COLOR = V4 tajweed, page 1, QCF2001 = V2, QCF_P001 = V1);
     the @font-face rules are added to the editor (and by the plugin's PHP to the site) for the pages that are used */
  /* sources in this order; the browser takes the next one by itself when one does not answer (the QUL CDN is the last) */
  function fontSources(v, n) {
    var f = v + '/p' + n + '.woff2';
    return [(K.origin || K.site) + '/fonts/qpc/' + f, 'https://cdn.jsdelivr.net/gh/abdullohukr/quranuz@main/fonts/qpc/' + f,
      'https://raw.githubusercontent.com/abdullohukr/quranuz/main/fonts/qpc/' + f,
      'https://huggingface.co/datasets/abdullohukr/khatt-al-quran-fonts/resolve/main/qpc/' + f,
      'https://archive.org/download/khatt-al-quran-fonts/qpc/' + f,
      'https://static-cdn.tarteel.ai/qul/fonts/quran_fonts/' + (v === 'v4' ? 'v4-tajweed' : v) + '/woff2/p' + n + '.woff2'];
  }
  function fontUrls(fam) {
    var m;
    if ((m = /^QCF4(\d{3})_COLOR$/.exec(fam))) return fontSources('v4', +m[1]);
    if ((m = /^QCF2(\d{3})$/.exec(fam))) return fontSources('v2', +m[1]);
    if ((m = /^QCF_P(\d{3})$/.exec(fam))) return fontSources('v1', +m[1]);
    return null;
  }
  /* per document (the editor canvas may appear later than the first ayah): a style is added once for each family */
  function ensureFonts(html) {
    var found = String(html || '').match(/QCF(?:4\d{3}_COLOR|2\d{3}|_P\d{3})/g);
    if (!found) return;
    var docs = [document];     // the editor canvas is a frame in newer WordPress
    [].forEach.call(document.querySelectorAll('iframe[name="editor-canvas"], .editor-visual-editor iframe'), function (f) {
      try { if (f.contentDocument && f.contentDocument.head) docs.push(f.contentDocument); } catch (x) {}
    });
    docs.forEach(function (d) {
      var done = d.__khattFonts || (d.__khattFonts = {}), css = '';
      found.forEach(function (fam) {
        if (done[fam]) return;
        var u = fontUrls(fam); if (!u) return;
        done[fam] = 1;
        css += "@font-face{font-family:'" + fam + "';src:" + u.map(function (x) { return "url('" + x + "') format('woff2')"; }).join(',') + ";font-display:swap}";
      });
      if (css) { var st = d.createElement('style'); st.textContent = css; d.head.appendChild(st); }
    });
  }
  /* spans with a style (page font, colour of the tajweed) must survive in the rich text: a format of our own */
  if (wp.richText && wp.richText.registerFormatType) {
    wp.richText.registerFormatType('khatt/span', { title: 'Khatt al-Quran', tagName: 'span', className: 'khatt-span',
      attributes: { style: 'style' }, edit: function () { return null; } });
  }

  var icon = el('svg', { viewBox: '0 0 24 24', width: 24, height: 24 },
    el('path', { d: 'M4 5.5C4 4.7 4.7 4 5.5 4H11v16H5.5A1.5 1.5 0 0 1 4 18.5v-13Zm9-1.5h5.5c.8 0 1.5.7 1.5 1.5v13c0 .8-.7 1.5-1.5 1.5H13V4Z', fill: 'currentColor' }));

  /* the paragraphs of the website's result -> paragraph blocks */
  function toBlocks(html) {
    var box = document.createElement('div'); box.innerHTML = html;
    var blocks = [];
    [].forEach.call(box.querySelectorAll('span[style]'), function (sp) { sp.className = (sp.className ? sp.className + ' ' : '') + 'khatt-span'; });
    ensureFonts(html);
    [].forEach.call(box.children, function (p) {
      var st = p.style, rtl = p.getAttribute('dir') === 'rtl', align = st.textAlign;
      var attrs = { content: p.innerHTML, className: 'khatt-ayah' + (rtl ? ' khatt-ar' : '') + (align === 'justify' ? ' khatt-justify' : '') };
      if (rtl) attrs.direction = 'rtl';
      if (align === 'left' || align === 'right' || align === 'center') attrs.align = align;
      var typo = {};
      if (st.fontSize) typo.fontSize = st.fontSize;
      if (st.lineHeight) typo.lineHeight = st.lineHeight;
      if (Object.keys(typo).length) attrs.style = { typography: typo };
      blocks.push(wp.blocks.createBlock('core/paragraph', attrs));
    });
    return blocks;
  }

  /* the blocks of the last insert (for "Undo"): their ids, and the text they had when they were put in */
  var lastInsert = null;
  /* the content as text (typing in the editor gives a rich-text object, not a string) */
  function snapshot(ids) {
    var sel = wp.data.select('core/block-editor');
    return JSON.stringify(ids.map(function (id) { var b = sel.getBlock(id); return b ? String(b.attributes.content == null ? '' : b.attributes.content) : null; }));
  }
  function undoInsert() {
    if (!lastInsert) throw new Error('none');
    var sel = wp.data.select('core/block-editor'), ids = lastInsert.ids;
    if (ids.every(function (id) { return !sel.getBlock(id); })) { lastInsert = null; throw new Error('gone'); }   // already taken out (Ctrl+Z)
    if (ids.some(function (id) { return !sel.getBlock(id); }) || snapshot(ids) !== lastInsert.snap) throw new Error('changed');   // edited: leave the person's words alone
    wp.data.dispatch('core/block-editor').removeBlocks(ids);
    lastInsert = null;
  }
  /* at the cursor: replace an empty paragraph, otherwise go right after the selected block (or at the end) */
  function insert(html) {
    var blocks = toBlocks(html);
    if (!blocks.length) throw new Error('empty');
    var sel = wp.data.select('core/block-editor'), disp = wp.data.dispatch('core/block-editor');
    var id = sel.getSelectedBlockClientId();
    if (id) {
      var b = sel.getBlock(id);
      if (b && b.name === 'core/paragraph' && !String(b.attributes.content || '').replace(/<[^>]*>|&nbsp;|\s/g, '')) {
        disp.replaceBlocks(id, blocks);
      } else {
        disp.insertBlocks(blocks, sel.getBlockIndex(id) + 1, sel.getBlockRootClientId(id));
      }
    } else {
      disp.insertBlocks(blocks);
    }
    var ids = blocks.map(function (b) { return b.clientId; });
    lastInsert = { ids: ids, snap: snapshot(ids) };
  }

  /* an existing post: load the page fonts of the ayahs that are already in it (the text is scanned only when the blocks change) */
  var lastBlocks = null, lastAll = '';
  wp.data.subscribe(function () {
    var sel = wp.data.select('core/block-editor'); if (!sel || !sel.getBlocks) return;
    var cur = sel.getBlocks();
    if (cur !== lastBlocks) {
      lastBlocks = cur;
      lastAll = JSON.stringify(cur.map(function (b) { return b.attributes && b.attributes.content; }));
      if (!/QCF/.test(lastAll)) lastAll = '';
    }
    if (lastAll) ensureFonts(lastAll);      // cheap: a document that has the style is skipped
  });
  K.insert = insert; K.undo = undoInsert;                  // also used by the tests
  window.KhattAlQuran = K;

  /* live search: the selected text of the editor (the page and the editor canvas frame) goes to the panel, every 1.2 s while it is on */
  var liveFrame = null, liveLast = '';
  setInterval(function () {
    if (!liveFrame || document.hidden) return;
    var docs = [document];
    [].forEach.call(document.querySelectorAll('iframe[name="editor-canvas"], .editor-visual-editor iframe'), function (fr) { try { if (fr.contentDocument) docs.push(fr.contentDocument); } catch (x) {} });
    var txt = '';
    docs.forEach(function (d) { try { var t = String(d.getSelection && d.getSelection() || '').trim(); if (t && !txt) txt = t; } catch (x) {} });
    if (txt && /[\u0600-\u06FF]/.test(txt) && txt !== liveLast) {
      liveLast = txt;
      try { liveFrame.contentWindow.postMessage({ type: 'khatt-search', q: txt.slice(0, 400), live: true }, K.origin || K.site); } catch (x) {}
    }
  }, 1200);

  function Panel() {
    var ref = wp.element.useRef(null);
    wp.element.useEffect(function () {
      function onMessage(e) {
        var f = ref.current, d = e.data;
        if (!f || e.origin !== (K.origin || K.site) || e.source !== f.contentWindow || !d) return;
        if (d.type === 'khatt-undo') {
          var uok = true, uerr = '';
          try { undoInsert(); } catch (x) { uok = false; uerr = String(x && x.message || x); }
          f.contentWindow.postMessage({ type: 'khatt-result', ok: uok, undo: true, error: uerr }, K.origin || K.site);
          return;
        }
        if (d.type === 'khatt-live') { liveFrame = d.on ? f : null; liveLast = ''; return; }
        if (d.type !== 'khatt-insert' || !d.html) return;
        var ok = true, err = '';
        try { insert(d.html); } catch (x) { ok = false; err = String(x && x.message || x); }
        f.contentWindow.postMessage({ type: 'khatt-result', ok: ok, error: err }, K.origin || K.site);
      }
      window.addEventListener('message', onMessage);
      return function () { window.removeEventListener('message', onMessage); };
    }, []);
    return el('iframe', { ref: ref, className: 'khatt-sidebar-frame', src: K.url, title: 'Khatt al-Quran',
                          allow: 'clipboard-write' });
  }

  wp.plugins.registerPlugin('khatt-al-quran', {
    icon: icon,
    render: function () {
      return el(wp.element.Fragment, null,
        MoreItem ? el(MoreItem, { target: 'khatt-sidebar', icon: icon }, 'Khatt al-Quran') : null,
        el(PluginSidebar, { name: 'khatt-sidebar', title: 'Khatt al-Quran', icon: icon, className: 'khatt-sidebar' }, el(Panel)));
    }
  });

  /* the first time: open the panel by itself, so nobody has to look for it */
  try {
    if (!window.localStorage.getItem('khatt-sidebar-seen')) {
      window.localStorage.setItem('khatt-sidebar-seen', '1');
      wp.domReady(function () {
        setTimeout(function () {
          var d = wp.data.dispatch('core/edit-post');
          if (d && d.openGeneralSidebar) d.openGeneralSidebar('khatt-al-quran/khatt-sidebar');
        }, 800);
      });
    }
  } catch (x) {}
})(window.wp);
