/* Khatt al-Quran picker: the website in a dialog. Its "Insert" button posts {type: 'khatt-insert', html, text};
   only messages from the website itself are taken. */
(function () {
  'use strict';
  var C = window.KhattAlQuran || {};
  function pick(onInsert) {
    var wrap = document.createElement('div'), box = document.createElement('div'), head = document.createElement('div');
    var close = document.createElement('button'), frame = document.createElement('iframe');
    wrap.className = 'khatt-modal';
    box.className = 'khatt-modal-box';
    head.className = 'khatt-modal-head';
    head.textContent = C.title || 'Quran ayah';
    close.type = 'button'; close.className = 'khatt-modal-close'; close.setAttribute('aria-label', C.close || 'Close'); close.textContent = '\u00d7';
    frame.src = C.url; frame.setAttribute('allow', 'clipboard-write');
    head.appendChild(close); box.appendChild(head); box.appendChild(frame); wrap.appendChild(box);
    document.body.appendChild(wrap);
    function done() { window.removeEventListener('message', onMessage); document.removeEventListener('keydown', onKey); wrap.remove(); }
    function onKey(e) { if (e.key === 'Escape') done(); }
    function onMessage(e) {
      var d = e.data;
      if (e.origin !== C.site || e.source !== frame.contentWindow || !d || d.type !== 'khatt-insert' || !d.html) return;
      frame.contentWindow.postMessage({ type: 'khatt-result', ok: true }, C.site);
      done();
      onInsert(d.html, d.text);
    }
    close.addEventListener('click', done);
    wrap.addEventListener('click', function (e) { if (e.target === wrap) done(); });
    window.addEventListener('message', onMessage);
    document.addEventListener('keydown', onKey);
  }
  /* the inserted markup: the paragraphs from the website inside one container */
  function wrapHtml(html) { return '<div class="khatt-ayah">' + html + '</div>'; }
  C.pick = pick;
  C.wrap = wrapHtml;
  window.KhattAlQuran = C;
  /* classic editor: the "Ayah" button next to "Add Media" */
  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('.khatt-classic-button');
    if (!b) return;
    e.preventDefault();
    pick(function (html) { if (window.send_to_editor) window.send_to_editor(wrapHtml(html)); });
  });
})();
