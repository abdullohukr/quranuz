=== Khatt al-Quran ===
Contributors: abdullohukr
Tags: quran, islam, arabic, translation, tafsir
Requires at least: 5.8
Tested up to: 7.1
Requires PHP: 7.0
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Find Quran ayahs and insert them into posts and pages with translation and tafsir.

== Description ==

Khatt al-Quran inserts Quran ayahs into WordPress posts and pages:

* the Arabic text of several mushafs (Uthmani, Imlaei, IndoPak, tajweed …), with brackets, isti'adhah, basmalah and a reference such as [يونس ١];
* translations in 90+ languages and tafsirs, with a reference such as (Yunus: 1);
* ayah numbers, hizb, sajdah and pause marks on or off;
* fonts, sizes, bold, colour and alignment as set in the picker.

Use the block **Quran ayah** (block editor) or the **Ayah** button above the classic editor. The picker is the
website https://quran.abdulloh.org/ in a dialog; the result is saved in the post as ordinary HTML, so nothing is
loaded from other servers when visitors read it. The Arabic font (Scheherazade New, SIL Open Font License) comes
with the plugin.

== Installation ==

1. Plugins → Add New → Upload Plugin → choose `khatt-al-quran.zip` → Install → Activate.
2. In a post: add the block "Quran ayah" (or press "Ayah" in the classic editor), find the ayah, press "Insert".

== External services ==

This plugin uses one external service: **Khatt al-Quran** (https://quran.abdulloh.org/), the picker in which the
ayah, translation and tafsir are chosen.

* What it is used for: finding Quran ayahs, translations and tafsirs and producing the HTML that is inserted into the post.
* When it is contacted: only in the post editor, when the person writing the post opens the block "Quran ayah" or
  presses the "Ayah" button. It is never contacted on the public site: visitors get the saved HTML and the bundled font.
* What is sent: nothing from the WordPress site. The browser of the editing person loads the picker page; the
  service receives the usual request data (IP address, browser user agent) and stores no account or tracking data.
  The ayah texts and translations themselves are loaded from raw.githubusercontent.com (GitHub), the public
  repository the service publishes its data in.
  The picker page also loads Microsoft's Office JavaScript library from appsforoffice.microsoft.com (it is the
  same page that runs inside Microsoft Word); outside Word it does nothing.
* Terms of use: https://quran.abdulloh.org/terms.html
* Privacy policy: https://quran.abdulloh.org/privacy.html
* GitHub terms: https://docs.github.com/site-policy/github-terms/github-terms-of-service ·
  privacy: https://docs.github.com/site-policy/privacy-policies/github-general-privacy-statement
* Microsoft terms: https://www.microsoft.com/legal/terms-of-use · privacy: https://privacy.microsoft.com/privacystatement

== Screenshots ==

1. Insert Quran ayahs with translation: the ayah, the translation and the reference in one click.
2. Search in Arabic (with or without diacritics), by surah name, by reference such as 2:255, or in any translation.
3. Choose exactly what is inserted: brackets, isti'adhah, basmalah, references, ayah numbers, hizb, sajdah and pause marks.
4. About 200 translations in 90+ languages and about 100 tafsirs.

== Changelog ==

= 1.0.0 =
* First version: block "Quran ayah", classic editor button, bundled Arabic font.
