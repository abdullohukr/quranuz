=== Khatt al-Quran ===
Contributors: abdullohukr
Tags: quran, islam, arabic, translation, tafsir
Requires at least: 5.8
Tested up to: 7.1
Requires PHP: 7.0
Stable tag: 3.15.3
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Find Quran ayahs and insert them into posts and pages with translation and tafsir.

== Description ==

Khatt al-Quran inserts Quran ayahs into WordPress posts and pages:

* the Arabic text of several mushafs (Uthmani, Imlaei, IndoPak, tajweed …), with brackets, isti'adhah, basmalah and a reference such as [يونس ١];
* translations in 90+ languages and tafsirs, with a reference such as (Yunus: 1);
* ayah numbers, hizb, sajdah and pause marks on or off;
* fonts, sizes, bold, colour and alignment as set in the picker.

In the block editor open the **Khatt al-Quran** panel (the book icon at the top right; it opens by itself the first time). Put the cursor where the ayah should go, find it in the panel and press **Insert**: the ayah and its translation are inserted as ordinary paragraphs, which you can edit like any other text. The classic editor has an **Ayah** button above the editor. The panel is the
website https://quran.abdulloh.org/ in a frame; the result is saved in the post as ordinary HTML, so nothing is
loaded from other servers when visitors read it. The block **Quran ayah** of version 1.0 still works. The Arabic font (Scheherazade New, SIL Open Font License) comes
with the plugin.



1. Plugins → Add New → Upload Plugin → choose `khatt-al-quran.zip` → Install → Activate.
2. In a post: add the block "Quran ayah" (or press "Ayah" in the classic editor), find the ayah, press "Insert".

== External services ==

This plugin uses one external service: **Khatt al-Quran** (https://quran.abdulloh.org/), the picker in which the
ayah, translation and tafsir are chosen.

* What it is used for: finding Quran ayahs, translations and tafsirs and producing the HTML that is inserted into the post.
* When it is contacted: only in the post editor, when the person writing the post opens the "Khatt al-Quran" panel, the block
  "Quran ayah" or the "Ayah" button. It is never contacted on the public site: visitors get the saved HTML and the bundled font.
* What is sent: nothing from the WordPress site. The browser of the editing person loads the picker page; the
  service receives the usual request data (IP address, browser user agent) and stores no account or tracking data.
  The ayah texts and translations themselves are loaded from raw.githubusercontent.com (GitHub), the public
  repository the service publishes its data in.
  The picker page also loads Microsoft's Office JavaScript library from appsforoffice.microsoft.com (it is the
  same page that runs inside Microsoft Word); outside Word it does nothing.
* Terms of use: https://quran.abdulloh.org/terms.html
* Privacy policy: https://quran.abdulloh.org/privacy.html
* GitHub terms: https://docs.github.com/site-policy/github-terms/github-terms-of-service ·
  privacy: https://docs.github.com/site-policy/privacy-policies/github-general-privacy-statement
* Microsoft terms: https://www.microsoft.com/legal/terms-of-use · privacy: https://privacy.microsoft.com/privacystatement

The page fonts of the QPC mushafs are the only other thing loaded, and only when a post contains an ayah in such a mushaf. The visitor's browser asks for the font file of each Mushaf page the post uses (for example `fonts/qpc/v4/p1.woff2`), trying these sources in order until one answers: https://quran.abdulloh.org/, GitHub (cdn.jsdelivr.net and raw.githubusercontent.com, repository abdullohukr/quranuz), Hugging Face (huggingface.co), archive.org, and last the QUL font CDN (static-cdn.tarteel.ai). Nothing from the visitor or the site is sent except the normal request for those font files. Posts without such ayahs contact none of them.

== Screenshots ==

1. Insert Quran ayahs with translation: the ayah, the translation and the reference in one click.
2. Search in Arabic (with or without diacritics), by surah name, by reference such as 2:255, or in any translation.
3. Choose exactly what is inserted: brackets, isti'adhah, basmalah, references, ayah numbers, hizb, sajdah and pause marks.
4. About 200 translations in 90+ languages and about 100 tafsirs.

== Changelog ==

= 3.15.1 =
* The version of the plugin now follows the version of Khatt al-Quran releases. Nothing else changed since 1.1.5.

= 1.1.5 =
* The editor panel icon is the Khatt al-Quran logo.

= 1.1.4 =
* Live search reacts faster; the key Alt+F in the panel searches the text selected in the editor once.

= 1.1.3 =
* Live search: when it is switched on in the panel, the Arabic text selected in the editor is searched at once.

= 1.1.2 =
* The panel's "Undo" button takes the last inserted ayah out of the post again (only if it was not edited since; text typed by hand counts as an edit).

= 1.1.1 =
* The page fonts of the QPC mushafs come from a chain of sources: the Khatt al-Quran site, GitHub (jsDelivr), Hugging Face, archive.org, and the QUL font CDN last, so one outage does not break the ayahs.

= 1.1.0 =
* A side panel in the block editor (like the task pane in Word): the ayah and its translation are inserted at the cursor as ordinary paragraphs. The old block "Quran ayah" and the classic editor button are unchanged.
* The page-font (QPC) mushafs are inserted as text; their fonts are declared automatically in the editor and on the site.

= 1.0.0 =
* First version: block "Quran ayah", classic editor button, bundled Arabic font.
