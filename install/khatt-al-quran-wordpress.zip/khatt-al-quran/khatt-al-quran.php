<?php
/**
 * Plugin Name:       Khatt al-Quran
 * Plugin URI:        https://quran.abdulloh.org/
 * Description:       Find Quran ayahs and insert them into posts and pages: the Arabic text of several mushafs, translations in 90+ languages, tafsirs, isti'adhah, basmalah and a reference. A block "Quran ayah" and an "Ayah" button in the classic editor.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.0
 * Author:            Abdulloh Hamidulloh al-Madiyniy
 * Author URI:        https://quran.abdulloh.org/
 * License:           GPL-2.0-or-later
 * Text Domain:       khatt-al-quran
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'KHATT_VERSION', '1.0.0' );
define( 'KHATT_SITE', 'https://quran.abdulloh.org' );

/* The picker: the website in a dialog (?host=wp); its "Insert" button sends ready HTML (see sendToHost in web/app.js). */
function khatt_register() {
	$url = plugin_dir_url( __FILE__ );
	wp_register_style( 'khatt-al-quran', $url . 'assets/style.css', array(), KHATT_VERSION );
	wp_register_script( 'khatt-picker', $url . 'assets/picker.js', array(), KHATT_VERSION, true );
	wp_localize_script( 'khatt-picker', 'KhattAlQuran', array(
		'site'  => KHATT_SITE,
		'url'   => KHATT_SITE . '/index.html?host=wp',
		'title' => __( 'Quran ayah', 'khatt-al-quran' ),
		'close' => __( 'Close', 'khatt-al-quran' ),
	) );
	wp_register_script( 'khatt-block', $url . 'assets/block.js',
		array( 'khatt-picker', 'wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-i18n' ), KHATT_VERSION, true );
	register_block_type( 'khatt/ayah', array(
		'editor_script' => 'khatt-block',
		'style'         => 'khatt-al-quran',
	) );
}
add_action( 'init', 'khatt_register' );

/* Classic editor: an "Ayah" button next to "Add Media" */
function khatt_media_button() {
	wp_enqueue_script( 'khatt-picker' );
	wp_enqueue_style( 'khatt-al-quran' );
	echo '<button type="button" class="button khatt-classic-button">'
		. '<span class="khatt-classic-icon" aria-hidden="true">&#xFD3E; &#xFD3F;</span> ' . esc_html__( 'Ayah', 'khatt-al-quran' ) . '</button>';
}
add_action( 'media_buttons', 'khatt_media_button', 20 );

/* The Arabic font on the site, for ayahs inserted with the classic editor too */
function khatt_front_style() {
	if ( is_singular() && false !== strpos( (string) get_post_field( 'post_content', get_queried_object_id() ), 'khatt-ayah' ) ) {
		wp_enqueue_style( 'khatt-al-quran' );
	}
}
add_action( 'wp_enqueue_scripts', 'khatt_front_style' );
