<?php
/**
 * Plugin Name:       Khatt al-Quran
 * Plugin URI:        https://quran.abdulloh.org/
 * Description:       Find Quran ayahs and insert them into posts and pages: the Arabic text of several mushafs, translations in 90+ languages, tafsirs, isti'adhah, basmalah and a reference. A side panel in the editor (like the task pane in Word) inserts the ayah as ordinary text; the classic editor has an "Ayah" button.
 * Version:           3.15.3
 * Requires at least: 5.8
 * Requires PHP:      7.0
 * Author:            Abdulloh Hamidulloh al-Madiyniy
 * Author URI:        https://quran.abdulloh.org/
 * License:           GPL-2.0-or-later
 * Text Domain:       khatt-al-quran
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'KHATT_VERSION', '3.15.3' );
define( 'KHATT_SITE', 'https://quran.abdulloh.org' );

/* The picker: the website in a dialog (?host=wp); its "Insert" button sends ready HTML (see sendToHost in web/app.js). */
function khatt_register() {
	$url  = plugin_dir_url( __FILE__ );
	$site = untrailingslashit( apply_filters( 'khatt_site', KHATT_SITE ) ); // a filter only for testing against a local copy of the site
	wp_register_style( 'khatt-al-quran', $url . 'assets/style.css', array(), KHATT_VERSION );
	wp_register_script( 'khatt-picker', $url . 'assets/picker.js', array(), KHATT_VERSION, true );
	wp_localize_script( 'khatt-picker', 'KhattAlQuran', array(
		'site'  => $site,
		'origin' => preg_replace( '#^(https?://[^/]+).*$#', '$1', $site ),
		'url'   => $site . '/index.html?host=wp',
		'title' => __( 'Quran ayah', 'khatt-al-quran' ),
		'close' => __( 'Close', 'khatt-al-quran' ),
	) );
	wp_register_script( 'khatt-block', $url . 'assets/block.js',
		array( 'khatt-picker', 'wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-i18n' ), KHATT_VERSION, true );
	wp_register_script( 'khatt-sidebar', $url . 'assets/sidebar.js',
		array( 'khatt-picker', 'wp-plugins', 'wp-rich-text', 'wp-edit-post', 'wp-editor', 'wp-element', 'wp-data', 'wp-blocks', 'wp-dom-ready', 'wp-i18n' ), KHATT_VERSION, true );
	register_block_type( 'khatt/ayah', array(
		'editor_script' => 'khatt-block',
		'style'         => 'khatt-al-quran',
	) );
}
add_action( 'init', 'khatt_register' );

/* Block editor: the side panel (the website in a frame; the ayah goes into the post as ordinary paragraphs) */
function khatt_editor_assets() {
	wp_enqueue_script( 'khatt-sidebar' );
}
add_action( 'enqueue_block_editor_assets', 'khatt_editor_assets' );

/* The styles of the ayah paragraphs: in the editor and on the site (only on posts that contain an ayah) */
function khatt_block_assets() {
	if ( is_admin() ) {
		wp_enqueue_style( 'khatt-al-quran' );
	}
}
add_action( 'enqueue_block_assets', 'khatt_block_assets' );

/* Classic editor: an "Ayah" button next to "Add Media" */
function khatt_media_button() {
	wp_enqueue_script( 'khatt-picker' );
	wp_enqueue_style( 'khatt-al-quran' );
	echo '<button type="button" class="button khatt-classic-button">'
		. '<span class="khatt-classic-icon" aria-hidden="true">&#xFD3E; &#xFD3F;</span> ' . esc_html__( 'Ayah', 'khatt-al-quran' ) . '</button>';
}
add_action( 'media_buttons', 'khatt_media_button', 20 );

/* QPC page fonts (one web font per Mushaf page): the family name says which file it is, so the @font-face rules
   are made from the post itself: QCF4001_COLOR = V4 tajweed page 1, QCF2001 = V2, QCF_P001 = V1. Only the pages
   that the post uses are declared, and a browser loads only those files. Each file has a chain of 6 sources, the
   same as the site: the site itself (KHATT_SITE), jsDelivr, raw.githubusercontent.com, Hugging Face, archive.org,
   and the public QUL CDN of Tarteel last (see "External services" in readme.txt). */
function khatt_font_sources( $v, $n ) {
	$f = $v . '/p' . (int) $n . '.woff2';
	$u = ( 'v4' === $v ) ? 'v4-tajweed' : $v;
	// the browser takes the next source by itself when one does not answer; Tarteel's QUL CDN is the last one
	return array(
		KHATT_SITE . '/fonts/qpc/' . $f,
		'https://cdn.jsdelivr.net/gh/abdullohukr/quranuz@main/fonts/qpc/' . $f,
		'https://raw.githubusercontent.com/abdullohukr/quranuz/main/fonts/qpc/' . $f,
		'https://huggingface.co/datasets/abdullohukr/khatt-al-quran-fonts/resolve/main/qpc/' . $f,
		'https://archive.org/download/khatt-al-quran-fonts/qpc/' . $f,
		'https://static-cdn.tarteel.ai/qul/fonts/quran_fonts/' . $u . '/woff2/p' . (int) $n . '.woff2',
	);
}

function khatt_font_css( $content ) {
	if ( ! preg_match_all( '/QCF(?:4(\d{3})_COLOR|2(\d{3})|_P(\d{3}))/', (string) $content, $m, PREG_SET_ORDER ) ) {
		return '';
	}
	$done = array();
	$css  = '';
	foreach ( $m as $x ) {
		if ( isset( $done[ $x[0] ] ) ) {
			continue;
		}
		$done[ $x[0] ] = true;
		if ( ! empty( $x[1] ) ) {
			$src = khatt_font_sources( 'v4', $x[1] );
		} elseif ( ! empty( $x[2] ) ) {
			$src = khatt_font_sources( 'v2', $x[2] );
		} else {
			$src = khatt_font_sources( 'v1', $x[3] );
		}
		$list = array();
		foreach ( $src as $u ) {
			$list[] = "url('" . esc_url_raw( $u ) . "') format('woff2')";
		}
		$css .= "@font-face{font-family:'" . $x[0] . "';src:" . implode( ',', $list ) . ';font-display:swap}';
	}
	return $css;
}

/* The Arabic font on the site, for ayahs inserted with the classic editor too */
function khatt_front_style() {
	if ( ! is_singular() ) {
		return;
	}
	$content = (string) get_post_field( 'post_content', get_queried_object_id() );
	if ( false !== strpos( $content, 'khatt-ayah' ) || false !== strpos( $content, 'QCF' ) ) {
		wp_enqueue_style( 'khatt-al-quran' );
		$css = khatt_font_css( $content );
		if ( $css ) {
			wp_add_inline_style( 'khatt-al-quran', $css );
		}
	}
}
add_action( 'wp_enqueue_scripts', 'khatt_front_style' );
