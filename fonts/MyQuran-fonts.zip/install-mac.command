#!/bin/bash
# MyQuran: install the fonts of this archive into ~/Library/Fonts (Word for Mac does not see subfolders).
# Double-click this file. If macOS blocks it: right-click -> Open -> Open.
cd "$(dirname "$0")"
mkdir -p "$HOME/Library/Fonts"
find fonts \( -iname '*.ttf' -o -iname '*.otf' \) -exec cp -f {} "$HOME/Library/Fonts/" \;
rm -f "$HOME/Library/Containers/com.microsoft.Word/Data/Library/Caches/Microsoft/fontLookupCache"*.plist
echo "Fonts installed. Restart Word. / Шрифтлар ўрнатилди. Word'ни қайта ишга туширинг."
read -n 1 -s -r -p "Press any key..."
